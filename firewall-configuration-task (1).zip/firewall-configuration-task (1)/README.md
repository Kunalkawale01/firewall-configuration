# Firewall Configuration Task (Windows/Linux)

## Objective
Configure and test basic firewall rules to allow or block specific network traffic using:
- **UFW (Uncomplicated Firewall)** on Linux
- **Windows Defender Firewall** on Windows

## Tools Used
- **Linux (Ubuntu 20.04+)** — UFW
- **Windows 10/11** — Windows Defender Firewall
- **Telnet Utility** — for testing blocked ports

## Steps (Linux - UFW)

**Check current firewall status**
```bash
sudo ufw status
```

**Enable firewall**
```bash
sudo ufw enable
```

**List current rules**
```bash
sudo ufw status numbered
```

**Block inbound traffic on port 23 (Telnet)**
```bash
sudo ufw deny 23
```

**Test the rule**
```bash
telnet localhost 23
```
Expected: `Connection refused`

**Allow SSH (port 22)**
```bash
sudo ufw allow 22
```

**Remove the block rule**
```bash
sudo ufw delete deny 23
```
## Steps (Windows Firewall)

1. Open **Windows Defender Firewall with Advanced Security**
2. Go to **Inbound Rules → New Rule**
3. Select **Port → TCP → 23 → Block the connection**
4. Test using:
   ```bash
   telnet localhost 23
   ```
   Expected: *Connection failed*
5. Add a new rule to allow port **22 (SSH)**
6. Remove test block rule to restore defaults

## Understanding Firewall Filtering
- A firewall filters network packets based on **ports**, **IP addresses**, and **protocols**.
- Rules determine whether a packet is **allowed** or **denied**.
- Example:
  - `sudo ufw deny 23` → Blocks Telnet
  - `sudo ufw allow 22` → Allows SSH

## Deliverables
Include screenshots of:
- Firewall rules before/after
- Blocking port 23
- Telnet connection test
- Rule removal

## Report
See [REPORT.md](REPORT.md) for detailed documentation.
