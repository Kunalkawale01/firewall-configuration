#!/bin/bash
# Firewall Setup Script - UFW (Ubuntu/Linux)
# Author: Kunal Kawale

echo "Checking UFW status..."
sudo ufw status

echo "Enabling UFW..."
sudo ufw enable

echo "Blocking port 23 (Telnet)..."
sudo ufw deny 23

echo "Allowing port 22 (SSH)..."
sudo ufw allow 22

echo "Listing current rules..."
sudo ufw status numbered

echo "Testing Telnet connection..."
telnet localhost 23 || echo "Connection refused (blocked as expected)"

echo "Removing block rule for port 23..."
sudo ufw delete deny 23

echo "Final firewall status:"
sudo ufw status numbered
