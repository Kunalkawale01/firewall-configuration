# Firewall Configuration Internship Report

## Task 4: Setup and Use a Firewall on Windows/Linux

### Objective
Configure and test basic firewall rules to allow or block network traffic using Windows Firewall or UFW.

### Tools Used
- **UFW (Ubuntu/Linux)**
- **Windows Defender Firewall**
- **Telnet utility**

### Windows Steps
1. Open Windows Firewall → Advanced settings.
2. Create inbound rule → Port → TCP → 23 → Block the connection.
3. Test using telnet (should fail).
4. Add rule to allow port 22 (SSH).
5. Remove test block rule.

### Linux Steps (UFW)
```bash
sudo ufw status
sudo ufw enable
sudo ufw deny 23
sudo ufw allow 22
sudo ufw delete deny 23
sudo ufw status numbered
```

### How Firewall Filters Traffic
A firewall inspects and controls network packets based on defined security rules. It allows or blocks data depending on:
- Source/Destination IP
- Port number
- Protocol (TCP/UDP)

### Outcome
- Successfully blocked and allowed network traffic.
- Verified filtering through telnet test.
- Learned how firewalls enforce access control in systems.